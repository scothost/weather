Dashboard... Logged in only..

<br />

<form id="randomInsert" action="<?php echo URL;?>dashboard/xhrInsert/" method="post">
	<input type="text" name="text" />
	<input type="submit" />
</form>

<br />

<div id="listInserts">
	
</div>