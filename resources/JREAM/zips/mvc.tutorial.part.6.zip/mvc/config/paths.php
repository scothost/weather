<?php

// Always provide a TRAILING SLASH (/) AFTER A PATH

define('URL', 'http://workspace/mvc/');


define('LIBS', 'libs/');