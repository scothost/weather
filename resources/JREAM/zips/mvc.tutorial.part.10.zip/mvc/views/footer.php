</div>

<div id="footer">
    (C) Footer
</div>

</body>
</html>