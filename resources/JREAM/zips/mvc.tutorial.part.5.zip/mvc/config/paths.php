<?php

define('URL', 'http://workspace/mvc/');